﻿#include <iostream>
#include <string>
using namespace std;

class Graphic
{
    Graphic* next;
protected:
    virtual void draw() {};
public:
    Graphic() { next = NULL; }
    virtual ~Graphic() {}
    void paint();
    Graphic* add(Graphic* p);
    Graphic* getNext() { return next; };
};

class Circle : public Graphic
{
protected:
    void draw();
};


class Line : public Graphic
{
protected:
    void draw();
};

class Rect : public Graphic
{
protected:
    void draw();
};


void Circle::draw()
{
    cout << "Circle::draw()" << endl;
}

void Line::draw()
{
    cout << "Line::draw()" << endl;
}

void Rect::draw()
{
    cout << "Rect::draw()" << endl;
}

void Graphic::paint()
{
    draw();
    if (next != NULL)
        next->paint();
    
}

Graphic* Graphic::add(Graphic* p)
{
    next = p;

    return next;
}

int main()
{
    Graphic* pStart{};
    Graphic* pLast{};
    Graphic* pNow{};
    int nInput{};

    pStart = new Circle();
    pLast = pStart;
    pNow = pStart;

    while (nInput != 4)
    {
        cout << "생성할 도형을 선택하세요" << endl;
        cout<< "1:Rect, 2:CIrcle, 3:Line, 4:finish >>";
        cin >> nInput;

        switch (nInput)
        {
        case 1:
            pNow->add(new Rect);
            break;
        case 2:
            pNow->add(new Circle);
            break;
        case 3:
            pNow->add(new Line);
            break;
        default:
            break;
        }
        pNow = pNow->getNext();
    }
    cout << " -- 연결된 모든 도형 출력 --" << endl;
    pStart->paint();
    pLast = pStart;
    cout << " -- 연결된 모든 도형 삭제 --" << endl;
}