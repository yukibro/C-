﻿#include <iostream>
using namespace std;

class BaseArray {
private:
	int capacity; // 동적 할당된 메모리 용량
	int* mem;
protected:
	BaseArray(int capacity = 100) {
		this->capacity = capacity; mem = new int[capacity];
	}
	~BaseArray() { delete[] mem; }
	void put(int index, int val) { mem[index] = val; }
	int get(int index) const { return mem[index]; }
	int getCapacity() { return capacity; }
};
class MyQueue : protected BaseArray {
	int front;
	int rear;
public:
	MyQueue(int cap) : BaseArray(cap) { front = 0; rear = 0; }
	int deQueue() {
		front += 1;
		return get(front);
	}
	void enQueue(int insertNum) {
		rear += 1;
		put(rear, insertNum);
	}
	int sizeOfQueue() { return getCapacity(); }
	int lengthOfQueue() { return (rear - front); }
};

int main()
{
	MyQueue mem(100);
	int inputSize;
	int inputNum;
	cout << "큐에 삽입할 정수개수를 입력하시오>> ";
	cin >> inputSize;
	for (int i = 0; i < inputSize; ++i) {
		cout << i + 1 << " ) ";
		cin >> inputNum;
		mem.enQueue(inputNum);
	}
	cout << "큐의 용량:" << mem.sizeOfQueue() << ", 큐의 크기:" << mem.lengthOfQueue() << endl;
	cout << "큐의 원소를 순서대로 제거하여 출력한다>> ";
	while (mem.lengthOfQueue() != 0) {
		cout << mem.deQueue() << " ";
	}
	cout << endl << "큐의 현재크기 : " << mem.lengthOfQueue() << endl;
}
